protocol Cars { //1. Создать протокол «Car» и описать свойства, общие для автомобилей, а также метод действия.
    var mark: String { get }
    var model: String { get }
    var typeOfCar: String { get }
    var engine: String { get set}
    var window: Bool { get set }
    func description()
}

// 2. Создать расширения для протокола «Car» и реализовать в них методы конкретных действий с автомобилем: открыть/закрыть окно, запустить/заглушить двигатель

extension Cars {
    mutating func engineSwitch(engine: String) -> String { //запуск двигателя
        switch engine {
        case "Запущен":
            self.engine = "Заглушен"
            print("Заглушили двигатель \(self.model)!")
        case "Заглушен":
            self.engine = "Запущен"
            print("Запустили двигатель \(self.model)!")
        default:
            self.engine = "Заглушен"
        }
        return self.engine
    }
    
    mutating func windowSwitch(window: Bool) -> Bool { //открытие окон через Bool
        switch window {
        case false:
            self.window = false
            print("Закрыли окно \(self.model)!")
        case true:
            self.window = true
            print("Открыли окно \(self.model)!")
        }
        return self.window
    }
}

//Создать два класса, имплементирующих протокол «Car»

class Bus: Cars {    // класс Bus описывает автобусы
    var mark: String
    var model: String
    var typeOfCar: String
    var engine: String
    var window: Bool
    var pax: Int    // отличия в классах. пассажиры чел.

    init(mark: String, model: String, typeOfCar: String, engine: String, window: Bool, pax: Int) {
        self.mark = mark
        self.model = model
        self.typeOfCar = typeOfCar
        self.engine = engine
        self.window = window
        self.pax = pax
    }
    
    func description() {
        print("Марка автобуса: \(self.mark), модель автобуса: \(self.model), тип автобуса: \(self.typeOfCar), состояние двигателя: \(self.engine), окна открыты: \(self.window), колличество мест: \(self.pax)")
    }
}

class Truck: Cars{      // класс Bus описывает грузовики
    var mark: String
    var model: String
    var typeOfCar: String
    var engine: String
    var window: Bool
    var cargo: Int       // отличия в классах. груз кг
    
    init(mark: String, model: String, typeOfCar: String, engine: String, window: Bool, cargo: Int) {
        self.mark = mark
        self.model = model
        self.typeOfCar = typeOfCar
        self.engine = engine
        self.window = window
        self.cargo = cargo
    }
    func description() {
        print("Марка грузовика: \(self.mark), модель: \(self.model), тип: \(self.typeOfCar), состояние двигателя: \(self.engine), окна открыты: \(self.window), грузоподьемность: \(self.cargo)")
    }
}

//5. Создать несколько объектов каждого класса.

var ikarus = Bus(mark: "Ikarus", model: "IK-2031", typeOfCar: "Пассажирский", engine: "Заглушен", window: false, pax: 55)
var paz = Bus(mark: "ПАЗик", model: "ПАЗ-3310", typeOfCar: "Пассажирский", engine: "Заглушен", window: false, pax: 32)
var neo = Bus(mark: "Неоплан", model: "НеО-01", typeOfCar: "Пассажирский", engine: "Заглушен", window: false, pax: 45)

var man = Truck(mark: "MAN", model: "M850", typeOfCar: "Фургон", engine: "Заглушен", window: false, cargo: 18000)
var kamaz = Truck(mark: "KAMAZ", model: "KA-1000", typeOfCar: "Самосвал", engine: "Заглушен", window: false, cargo: 15000)
var volvo = Truck(mark: "Вольво", model: "В 2000", typeOfCar: "Фургон", engine: "Заглушен", window: false, cargo: 20000)

// 6. Применить к ним различные действия. Вывести сами объекты в консоль.

ikarus.description()
ikarus.engineSwitch(engine: ikarus.engine)
ikarus.windowSwitch(window: true)

man.description()
man.engineSwitch(engine: man.engine)
man.windowSwitch(window: true)

print("\nНовое состояние машин\n")

ikarus.description()
man.description()
