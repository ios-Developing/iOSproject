//1, 2 задание. создание структуры
struct sportCar {
    var markOfCar: String
    var podactionYear: Int
    var volumeOfCar: Int
    var engineState: Bool
    var windowsStateOpen: Bool
    var volumeOfcarUsedInPersent: Double

    init(markOfCarSportCar: String, podactionYearSportCar: Int, volumeOfCarSportCar: Int, engineStateSportCar: Bool, windowsStateOpenSportCar: Bool, volumeOfcarUsedInPersentSportCar: Double) {
        self.markOfCar = markOfCarSportCar
        self.podactionYear = podactionYearSportCar
        self.volumeOfCar = volumeOfCarSportCar
        self.engineState = engineStateSportCar
        self.windowsStateOpen = windowsStateOpenSportCar
        self.volumeOfcarUsedInPersent = volumeOfcarUsedInPersentSportCar
    }
    
    mutating func engineState(actionEngine: Bool){ // метод изменения состояния двигателя
        self.engineState = actionEngine
    }
    mutating func windowsStateOpen(windowsStateOpen: Bool){ // метод функция изменения состояния окон
        self.windowsStateOpen = windowsStateOpen
    }
    mutating func volumeOfcarUsedInPersent(volumeOfcarUsedInPersent: Double){ // метод изменения загрузки
        self.volumeOfcarUsedInPersent = volumeOfcarUsedInPersent
    }
    
    func descriptionCar() { // описание авто
        print("\nMark of sport Car: \(markOfCar) \nYear of prodaction: \(podactionYear) \nCar volume of interior: \(volumeOfCar) ")
    }
    
    func descriptionCarState() { // описание состояния авто
    print("Engine is running: \(engineState) \nWindows is open: \(windowsStateOpen) \nUsed of interior volume: \(volumeOfcarUsedInPersent) %")
    }
    
}

var Lada = sportCar(markOfCarSportCar: "Lada 2108", podactionYearSportCar: 1990, volumeOfCarSportCar: 2, engineStateSportCar: false, windowsStateOpenSportCar: false, volumeOfcarUsedInPersentSportCar: 0)

// Lada.engineState(engineState: true) // вызов метода изменения состояния двигателя
Lada.windowsStateOpen(windowsStateOpen: true)
Lada.volumeOfcarUsedInPersent(volumeOfcarUsedInPersent: 10)



var Moskvich = sportCar(markOfCarSportCar: "Moskvich 412", podactionYearSportCar: 1985, volumeOfCarSportCar: 2, engineStateSportCar: false, windowsStateOpenSportCar: false, volumeOfcarUsedInPersentSportCar: 0)

// Moskvich.engineState(engineState: true) // вызов метода изменения состояния двигателя
Moskvich.windowsStateOpen(windowsStateOpen: true)
Moskvich.volumeOfcarUsedInPersent(volumeOfcarUsedInPersent: 10)



// 3 перечисление

enum Action { // перечисление c действиями с автомобилем
    case engineState(run: Bool)
    case windowsStateUp(up: Bool)
    case volumeOfcarUsedInPersent(loadInPrst: Double)
}


var actionEngine = Action.engineState(run: false)           // запуск двигателя
var actionWindows  = Action.windowsStateUp(up: false)                // открытие окон
var actionCargo  = Action.volumeOfcarUsedInPersent(loadInPrst: 58)    // загрузка багажника



Lada.descriptionCar() // описание авто Лада
Lada.descriptionCarState()

Moskvich.descriptionCar() // описание авто Москвич
Moskvich.descriptionCarState()


print("\n\(actionEngine)\n")

Moskvich.engineState(actionEngine: true) // вызов метода изменения состояния двигателя переменной из перечисления
Moskvich.descriptionCar() // описание авто Москвич
Moskvich.descriptionCarState() // описание состояния авто после вызова метода изменения состояния двигателя переменной из перечисления


// Truck для грузовика все то же самое! :)

struct truckCar {
    var markOfCar: String
    var podactionYear: Int
    var volumeOfCar: Int
    var engineState: Bool
    var windowsState: Bool
    var volumeOfcarUsedInPersent: Double
    
    init(markOfCarTruckCar: String, podactionYearTruckCar: Int, volumeOfCarTruckCar: Int, engineStateTruckCar: Bool, windowsStateTruckCar: Bool, volumeOfcarUsedInPersentTruckCar: Double) {
        self.markOfCar = markOfCarTruckCar
        self.podactionYear = podactionYearTruckCar
        self.volumeOfCar = volumeOfCarTruckCar
        self.engineState = engineStateTruckCar
        self.windowsState = windowsStateTruckCar
        self.volumeOfcarUsedInPersent = volumeOfcarUsedInPersentTruckCar
    }
    
}
