import Foundation

class Cars {    // Класс описывает размеры машин, а перечисление состояние двигателя
    
    enum engineState { // перечисление состояние двигателя, работает для всех машин
        case engineNew
        case engineUsed
        case engineBroken
        case engineAbsent
    }
    
    var lenght: Double
    var widht: Double
    var hight: Double
    var engine: engineState
    
    init(lenght: Double, widht: Double, hight: Double, engine: engineState) {
        self.lenght = lenght
        self.widht = widht
        self.hight = hight
        self.engine = engine
    }
    
    func engineFix(engine: engineState) -> Int {  // стоимость ремонта двигателя в зависимости от его состояния
        if engine == engineState.engineAbsent {
                return 1000 }
        else if  engine == engineState.engineBroken {
                return 500 }
        else if engine == engineState.engineUsed {
            return 200 } else {
                return 0
            }
    }
    
    func descriptionCar(lenght: Double, widht: Double, hight: Double, engine: engineState) {
        // print(lenght, widht, hight, engine, paxSeats, paxTotal, paxClass)
        print("Длина авто: \(lenght), ширина: \(widht), высота: \(hight),\nдвигатель: \(engine)")
    }
    
    func engineRepair(engine: engineState) {
       self.engine = .engineNew
    }
}

class Truck: Cars{  // подкласс Truck описывает грузовики
    var cargoVolume: Double
    var cargoTonnage: Int

    enum cargoAction { // перечисление действия с грузом
        case load
        case unload
        case leaveEmpty
        case leaveLoaded
    }
    
    var cargo: cargoAction
    
    init(lenght: Double, widht: Double, hight: Double, engine: engineState, cargoVolume: Double, cargoTonnage: Int, cargo: cargoAction) {
        self.cargoVolume = cargoVolume
        self.cargoTonnage = cargoTonnage
        self.cargo = cargo
        super.init(lenght: lenght, widht: widht, hight: hight, engine: engine)
        }
    
    func descriptionCar(lenght: Double, widht: Double, hight: Double, engine: engineState, cargoVolume: Double, cargoTonnage: Int, cargo: cargoAction) {
        // print(lenght, widht, hight, engine, paxSeats, paxTotal, paxClass)
        print("Длина грузовика: \(lenght), ширина: \(widht), высота: \(hight),\nдвигатель: \(engine), доп.объём груза: \(cargoVolume), доп.вес груза: \(cargoTonnage), действие с грузом: \(cargo)")
        print("Ремонт двигателя грузовика стоит: \(printTruck.engineFix(engine: printTruck.engine)) USD\n")
    }
    
    override func engineRepair(engine: engineState) { // переопределение функции
        print("Ремонт двигателя грузовика стоил: \(printTruck.engineFix(engine: printTruck.engine)) USD")
       self.engine = .engineNew
        print("Это был дорогой ремонт двигателя грузовика\n")
    }
    
}

class Bus: Cars{ // подкласс Bus описывает автобусы
    var paxSeats: Int = 0
    var paxTotal: Int = 0
    
    enum paxService { // перечисление пассажирский сервис
        case bussines
        case premium
        case econom
        case noSeat
    }
    
    var paxClass: paxService
    
    init(lenght: Double, widht: Double, hight: Double, engine: engineState ,paxSeats: Int, paxTotal: Int, paxClass: paxService) {
        self.paxSeats = paxSeats
        self.paxTotal = paxTotal
        self.paxClass = paxClass
        super.init(lenght: lenght, widht: widht, hight: hight, engine: engine)
    }
    
    func descriptionCar(lenght: Double, widht: Double, hight: Double, engine: engineState, paxSeats: Int, paxTotal: Int, paxClass: paxService) {
        // print(lenght, widht, hight, engine, paxSeats, paxTotal, paxClass)
        print("Длина автобуса: \(lenght), ширина: \(widht), высота: \(hight),\nдвигатель: \(engine), сидячих мест: \(paxSeats), всего мест: \(paxTotal), класс обслуживания: \(paxClass)")
        print("Ремонт двигателя автобуса стоит: \(printBus.engineFix(engine: printBus.engine)) USD\n")
    }
    
    override func engineRepair(engine: engineState) {   // переопределение функции
        print("Ремонт двигателя автобуса стоил: \(printBus.engineFix(engine: printBus.engine)) USD")
       self.engine = .engineNew
        print("Это был дорогущий ремонт автобусного двигателя\n")
    }

}

// создание объектов
var man = Truck(lenght: 10, widht: 4, hight: 4.5, engine: .engineBroken, cargoVolume: 15.5, cargoTonnage: 20, cargo: .load)
var volvo = Truck(lenght: 11, widht: 4.1, hight: 4.6, engine: .engineNew, cargoVolume: 17, cargoTonnage: 21,  cargo: .load)
var ikarus = Bus(lenght: 9, widht: 4, hight: 4, engine: .engineUsed, paxSeats: 35, paxTotal: 45, paxClass: .econom)
var paz = Bus(lenght: 11, widht: 4.4, hight: 4.5, engine: .engineAbsent, paxSeats: 40, paxTotal: 50, paxClass: .econom)

var printBus = paz      // в этой переменной будет печататься автобус (ПАЗ) (измените переменную)
var printTruck = man    // в этой переменной будет печататься грузовик (МАН)

paz.engineRepair(engine: paz.engine) // функция ремонта двигателя
// man.engineRepair(engine: man.engine) // "раскомментируйте" строку для ремонта двигателя

//вызов функций печати

printTruck.descriptionCar(lenght: printTruck.lenght, widht: printTruck.widht, hight: printTruck.hight, engine: printTruck.engine, cargoVolume: printTruck.cargoVolume, cargoTonnage: printTruck.cargoTonnage, cargo: printTruck.cargo)

printBus.descriptionCar(lenght: printBus.lenght, widht: printBus.widht, hight: printBus.hight, engine: printBus.engine, paxSeats: printBus.paxSeats, paxTotal: printBus.paxTotal, paxClass: printBus.paxClass)
