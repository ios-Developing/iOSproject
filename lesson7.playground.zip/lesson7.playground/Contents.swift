//import Foundation

enum errors: Error { // перечисление с ошибками
    case noName
    case wrongCalcTooBig
    case wrongCalcTooSmall
}

struct Calc {
    var a: Int
    var b: Int
    var c: Int
}

class calculation {
    var arrayNum = [
        "first" : Calc(a: 10, b: 20, c: 30),
        "second" : Calc(a: 20, b: 30, c: 40),
        "third" : Calc(a: 70, b: 80, c: 90)
    ]
    
    var fatalSummBig = 100 // максимальная сумма чисел
    var fatalSummSmall = 70 // минимальная сумма чисел
    
    
    func calcItself(arrayItem name: String) throws {
        guard let z = arrayNum[name] else {
            throw errors.noName
        }
        let temp = z.a + z.b + z.c
        guard temp > fatalSummBig else {
            throw errors.wrongCalcTooBig
        }
        guard temp < fatalSummSmall else {
            throw errors.wrongCalcTooSmall
        }
        print("Получено нормальное значение: \(temp)")
    }
}

func tryToDo (nam: String) throws {
    try calculation.calcItself(nam)
}
// почему функция не может принять параметр nam? туда же передается String!? calcItself и тут String...

do {
    try tryToDo(nam: "first")
} catch errors.noName {
    print("No File")
} catch errors.wrongCalcTooBig {
    print("Summ too big")
} catch errors.wrongCalcTooSmall {
    print("Summ too small")
}
