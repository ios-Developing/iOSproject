import Foundation

// 1. Реализовать свой тип коллекции «очередь» (queue) c использованием дженериков.

var countGoods: Int = 0  // кол-во товаров на складе


struct uName<Element> {
    
    var names = [Element]()
    
    mutating func enqueue(_ name: Element) {
        names.append(name)
        countGoods += 1
    }
    
    mutating func dequeue() -> Element {
        countGoods -= 1
        return names.remove(at: 0)
    }
    
//    func filter(item: Element) {                      // здесь ошибка: All paths through this function will call itself
//        print("Find \(goods.filter{$0 == item})")     // в разборе д/з ошибки нет! не могу понять.
//    }                                                 // остальное сделал сам
    
// 3. * Добавить свой subscript, который будет возвращать nil в случае обращения к несуществующему индексу.
    subscript(index: Int) -> String {
        get {
            if index == 0 {
           return "\nВсё! Склад опустел!"
            } else { return "Товаров осталось: \(countGoods)" }
            }
        }
    
}

var goods = uName<Any>()
var goodsSorted = [Any]()

// порядок поступления товаров

goods.enqueue("Eggs")
goods.enqueue("Butter")
goods.enqueue(777)          // портвейн 777 ;) тип Int
goods.enqueue("Milk")
goods.enqueue(true)         // просто тип Bool


while countGoods > 0 {
    // goods.filter(item: 777) здесь ошибка
    print("Списываем товар который поступил раньше: \(goods.dequeue())")
    print(goods[countGoods])

}
